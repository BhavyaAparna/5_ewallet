from django.shortcuts import render
#from app1.forms import UserForm
#from django.contrib.auth import authenticate, login, logout
from django.http import HttpResponseRedirect, HttpResponse
from django.urls import reverse
#from django.contrib.auth.decorators import login_required
#from app1.models import UserProfileInfo



def index(request):
    return render(request,'index.html')
'''def login(request):
    return render(request,'login.html')
def register(request):
    return render(request,'register.html')'''
'''@login_required
def special(request):
    return HttpResponse("You are logged in !")
@login_required
def user_logout(request):
    logout(request)
    return HttpResponseRedirect(reverse('index.html'))

def SIGNUP(request):
    registered = False
    print(request.method)
    if request.method == 'GET':
        user_form = UserForm(data=request.GET)
        print(user_form, 'Gautham')
        if user_form.is_valid():
            user = user_form.save()
            user.save()
            registered = True
            return render(request,'index.html',{'user_form':user_form,'registered':registered})
        else:
            print(user_form.errors)
    else:
        user_form = UserForm()
    return render(request,'SIGNUP.html',{'user_form':user_form,'registered':registered})
def index(request):
    #print(request.method)
    if request.method == 'POST' :
        username = request.POST.get('username')
        password = request.POST.get('password')
        user = authenticate(username=username, password=password) 
        a = UserProfileInfo.objects.filter(username=username).exists()
        b = UserProfileInfo.objects.filter(password=password).exists()
        if a and b:
            #login(request,user)
            return HttpResponseRedirect(reverse('about'))
       # else:
        #    return HttpResponse("Your account was inactive.")
        else:
            print("Someone tried to login and failed.")
            print("They used username: {} and password: {}".format(username,password))
            return HttpResponse("Invalid login details given")
    else:
        return render(request, 'index.html')'''

def card(request):
    return render(request,'card.html')
def table(request):
    return render(request,'table.html')
from django.contrib.auth.forms import UserCreationForm
from django.urls import reverse_lazy
from django.views import generic

class Register(generic.CreateView):
	form_class = UserCreationForm
	success_url = reverse_lazy('login')
	template_name = 'register.html'




    
