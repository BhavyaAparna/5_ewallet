from django.urls import path

from . import views

urlpatterns = [
    path('register/',views.Register.as_view(), name = 'register'),
    path('index', views.index, name='index'),
    #path('register',views.register,name = 'register'),
    #path('index',views.index,name = 'index'),
    path('card',views.card,name = 'card'),
    path('table',views.table,name = 'table'),
    #path('login',views.login,name = 'logout'),
]
